from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required,user_passes_test
# Create your views here.
from main.models import CostCodeModel,ClusterModel,GSTModel,LabourModel,PartyModel,RateModel,CountModel,RCModel,EntryModel,InvoiceRCModel,InvoiceModel,ICountModel,QCountModel,QTTModel
from django.http import HttpResponse,JsonResponse
from django.views.decorators.csrf import csrf_exempt

def Login(request):
    if request.method=="POST":
        username=request.POST.get('Username')
        password=request.POST.get('Password')
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('/')
    return render(request,"login.html")

def Logout(request):
    logout(request)
    return redirect('/')

@login_required(login_url='Login')
def home(request):
    return render(request,'dashboard.html')

@login_required(login_url='Login')
def Cluster(request):
    data=ClusterModel.objects.all()
    if request.method=="POST":    
        Name=request.POST.get('Name')
        Amount=request.POST.get('Amount')
        if request.POST.get('ATM'):
            ATM='True'
        else:
            ATM='False'
        if request.POST.get('Branch'):
            Branch='True'
        else:
            Branch='False'
        if request.POST.get('HubLocation'):
            HubLocation='True'
        else:
            HubLocation='False'
        dt=ClusterModel.objects.create(Name=Name,Amount=Amount,ATM=ATM,Branch=Branch,HubLocation=HubLocation)
        dt.save()
        return redirect('/Cluster')
    return render(request,'cluster.html',{'data':data})

@login_required(login_url='Login')
def EditCluster(request,id):
    data=ClusterModel.objects.get(id=id)
    if request.method=="POST":    
        data.Name=request.POST.get('Name')
        data.Amount=request.POST.get('Amount')
        if request.POST.get('ATM'):
            data.ATM='True'
        else:
            data.ATM='False'
        if request.POST.get('Branch'):
            data.Branch='True'
        else:
            data.Branch='False'
        if request.POST.get('HubLocation'):
            data.HubLocation='True'
        else:
            data.HubLocation='False'
        data.save()
        return redirect('/Cluster')
    return render(request,'editcluster.html',{'data':data})

@login_required(login_url='Login')
def DeleteCluster(request,id):
    data=ClusterModel.objects.get(id=id)
    data.delete()
    return redirect('/Cluster')

@login_required(login_url='Login')
def CallEntry(request):
    data=EntryModel.objects.filter(complet='0')
    return render(request,'callentry.html',{'data':data})

@csrf_exempt
def RCCODE(request):
    if request.method == 'POST':
        RC = request.POST.get('RC')
        RCL = RateModel.objects.get(CodeNo=RC)
        return JsonResponse({'RC':RCL.Rate})

@login_required(login_url='Login')
def AddCallEntry(request):
    try:
        CM=CountModel.objects.get(id=1)
        count = CM.Counter
    except CountModel.DoesNotExist:
        CM=CountModel.objects.create(Counter=1)
        count = 1
    Party=PartyModel.objects.all()
    PN={i.PartyName for i in Party}
    CC=CostCodeModel.objects.all()
    Cluster=ClusterModel.objects.all()
    RC = RateModel.objects.all()
    RCM=RCModel.objects.all()
    RCM2=RCModel.objects.filter(Counter=count)
    TAmount=0
    for i in RCM2:
        TAmount=TAmount+ eval(i.Amount)
    maindata={'Party':Party,'CC':CC,'CM':CM,'RC':RC,'RCM':RCM,'TAmount':TAmount,'PN':PN,'Cluster':Cluster}
    if request.method=="POST":
        Counter = request.POST.get('Counter')
        PartyName = request.POST.get('PartyName')
        City = request.POST.get('City')
        Branch = request.POST.get('Branch')
        Code = request.POST.get('Code')
        Cluster = request.POST.get('Cluster')
        Address = request.POST.get('Address')
        NO1 = request.POST.get('NO1')
        NO2 = request.POST.get('NO2')
        NO3 = request.POST.get('NO3')
        NO4 = request.POST.get('NO4')
        CallType = request.POST.get('CallType')
        Date = request.POST.get('Date')
        CloseDate = request.POST.get('CloseDate')
        CodeNo = request.POST.get('CodeNo')
        CostCode = request.POST.get('CostCode')
        ContactNo = request.POST.get('ContactNo')
        ContactPerson = request.POST.get('ContactPerson')
        Email = request.POST.get('Email')
        CCName = request.POST.get('CCName')
        Problem = request.POST.get('Problem')
        ChallanNo = request.POST.get('ChallanNo')
        ChallanDate = request.POST.get('ChallanDate')
        CallAllocatedTo = request.POST.get('CallAllocatedTo')
        EstimateRecd = request.POST.get('EstimateRecd')
        WorkEngaged = request.POST.get('WorkEngaged')
        Remark = request.POST.get('Remark')
        TotalAmount = request.POST.get('TotalAmount')
        data = EntryModel(Counter=Counter,PartyName=PartyName,City=City,Branch=Branch,Code=Code,Cluster=Cluster,Address=Address,NO1=NO1,NO2=NO2,NO3=NO3,NO4=NO4,CallType=CallType,Date=Date,CloseDate=CloseDate,CodeNo=CodeNo,CostCode=CostCode,ContactNo=ContactNo,ContactPerson=ContactPerson,Email=Email,CCName=CCName,Problem=Problem,ChallanNo=ChallanNo,ChallanDate=ChallanDate,CallAllocatedTo=CallAllocatedTo,EstimateRecd=EstimateRecd,WorkEngaged=WorkEngaged,Remark=Remark,TotalAmount=TotalAmount)
        data.save()
        CM.Counter = int(count)+1
        CM.save()
        return redirect('/CallEntry')
    return render(request,'addcallentry.html',maindata)

@login_required(login_url='Login')
def DeleteCallEntry(request,id):
    dt = EntryModel.objects.get(id=id)
    RC = RCModel.objects.filter(Counter= dt.Counter)
    dt.delete()
    RC.delete()
    return redirect('/CallEntry')

def EditCallEntry(request,pk):
    data=EntryModel.objects.get(Counter=pk)
    Party=PartyModel.objects.all()
    PN={i.PartyName for i in Party}
    RCM=RCModel.objects.filter(Counter=pk)
    CM=pk
    TAmount=0
    for i in RCM:
        TAmount=TAmount+ eval(i.Amount)
    return render(request,'editcallentry.html',{'data':data,'RCM':RCM,'CM':CM,'PN':PN,'TAmount':TAmount})

def Citys(request,PN):
    City = PartyModel.objects.filter(PartyName=PN)
    PN={i.City for i in City}
    City = list(PN)
    return JsonResponse({'City':City})

def Branch(request,City):
    Branch = PartyModel.objects.filter(City=City)
    PN={i.Branch for i in Branch}
    Branch = list(PN)
    return JsonResponse({'Branch':Branch})

def RCCreat(request):
    if request.method == 'POST':
        sid = request.POST.get('sid')
        Counter = request.POST['Counter']
        RCCode = request.POST['RCCode']
        RCDescription = request.POST['RCDescription']
        Quantity = request.POST['Quantity']
        Rate = request.POST['Rate']
        Labour = request.POST['Labour']
        Amount = request.POST['Amount']
        RC = RateModel.objects.get(CodeNo=RCCode)
        if sid == '':
            data=RCModel(Counter=Counter,RCCode=RCCode,Unit=RC.Unit,HSNCode=RC.HSNCode,RCDescription=RCDescription,Quantity=Quantity,Rate=Rate,Labour=Labour,Amount=Amount)
        else:
            data=RCModel(id=sid,Counter=Counter,RCCode=RCCode,Unit=RC.Unit,HSNCode=RC.HSNCode,RCDescription=RCDescription,Quantity=Quantity,Rate=Rate,Labour=Labour,Amount=Amount)
        data.save()
        # data load
        show=RCModel.objects.filter(Counter=Counter).values()
        RCM2=RCModel.objects.filter(Counter=Counter)
        TAmount=0
        for i in RCM2:
            TAmount=TAmount+ eval(i.Amount)
        show=list(show)
        return JsonResponse({'show':show,'TAmount':TAmount})

def RCEdit(request):
    if request.method == 'POST':
        id = request.POST.get('sid')
        data=RCModel.objects.get(pk=id)
        mydata={"id":data.id,"Counter":data.Counter,"RCCode":data.RCCode,"RCDescription":data.RCDescription,"Quantity":data.Quantity,"Rate":data.Rate,"Labour":data.Labour,"Amount":data.Amount}
        return JsonResponse(mydata)

def RCDelete(request):
    if request.method == 'POST':
        id = request.POST.get('sid')
        data=RCModel.objects.get(pk=id)
        i=data.Counter
        data.delete()
        RCM2=RCModel.objects.filter(Counter=i)
        TAmount=0
        for i in RCM2:
            TAmount=TAmount+ eval(i.Amount)
        return JsonResponse({'status':1,'TAmount':TAmount})
    else:
        return JsonResponse({'status':0})

def EntryClase(request):
    CM=CountModel.objects.get(id=1)
    RCM=RCModel.objects.filter(Counter=CM.Counter)
    RCM.delete()
    return redirect('/CallEntry')

@login_required(login_url='Login')
def PendingCall(request):
    data=EntryModel.objects.filter(CallType='Call',complet='0')
    return render(request,'pendingcall.html',{'data':data})

@login_required(login_url='Login')
def PendingWorkOrder(request):
    data=EntryModel.objects.filter(CallType='WorkOrder',complet='0')
    return render(request,'pendingworkorder.html',{'data':data})

@login_required(login_url='Login')
def CompleteCall(request):
    data=EntryModel.objects.filter(complet='1')
    return render(request,'completecall.html',{'data':data})

@login_required(login_url='Login')
def CostCode(request):
    data=CostCodeModel.objects.all()
    if request.method=="POST":    
        CostCode=request.POST.get('CostCode')
        Name=request.POST.get('Name')
        Remarks=request.POST.get('Remarks')
        dt=CostCodeModel.objects.create(CostCode=CostCode,Name=Name,Remarks=Remarks)
        dt.save()
        return redirect('/CostCode')
    return render(request,'costcode.html',{'data':data})

@login_required(login_url='Login')
def EditCostCode(request,id):
    data=CostCodeModel.objects.get(id=id)
    if request.method=="POST":    
        data.CostCode=request.POST.get('CostCode')
        data.Name=request.POST.get('Name')
        data.Remarks=request.POST.get('Remarks')
        data.save()
        return redirect('/CostCode')
    return render(request,'editcostcode.html',{'data':data})

@login_required(login_url='Login')
def DeleteCostCode(request,id):
    data=CostCodeModel.objects.get(id=id)
    data.delete()
    return redirect('/CostCode')

@login_required(login_url='Login')
def GST(request):
    data=GSTModel.objects.all()
    if request.method=="POST":    
        GSTName=request.POST.get('GSTName')
        SGST=request.POST.get('SGST')
        CGST=request.POST.get('CGST')
        dt=GSTModel.objects.create(GSTName=GSTName,SGST=SGST,CGST=CGST)
        dt.save()
        return redirect('/GST')
    return render(request,'GST.html',{'data':data})

@login_required(login_url='Login')
def EditGST(request,id):
    data=GSTModel.objects.get(id=id)
    if request.method=="POST":    
        data.GSTName=request.POST.get('GSTName')
        data.SGST=request.POST.get('SGST')
        data.CGST=request.POST.get('CGST')
        data.save()
        return redirect('/GST')
    return render(request,'editgst.html',{'data':data})

@login_required(login_url='Login')
def DeleteGST(request,id):
    data=GSTModel.objects.get(id=id)
    data.delete()
    return redirect('/GST')

@login_required(login_url='Login')
def Party(request):
    data=PartyModel.objects.all()
    return render(request,'party.html',{'data':data})

@login_required(login_url='Login')
def AddParty(request):
    data=ClusterModel.objects.all()
    if request.method=="POST":    
        Code=request.POST.get('Code')
        PartyName=request.POST.get('PartyName')
        Cluster=request.POST.get('Cluster')
        City=request.POST.get('City')
        Branch=request.POST.get('Branch')
        Address=request.POST.get('Address')
        GSTNo=request.POST.get('GSTNo')
        NO1=request.POST.get('NO1')
        NO2=request.POST.get('NO2')
        NO3=request.POST.get('NO3')
        NO4=request.POST.get('NO4')
        NO5=request.POST.get('NO5')
        NO6=request.POST.get('NO6')
        dt=PartyModel.objects.create(Code=Code,PartyName=PartyName,Cluster=Cluster,City=City,Branch=Branch,Address=Address,GSTNo=GSTNo,NO1=NO1,NO2=NO2,NO3=NO3,NO4=NO4,NO5=NO5,NO6=NO6)
        dt.save()
        return redirect('/Party')
    return render(request,'addparty.html',{'data':data})

@login_required(login_url='Login')
def EditParty(request,id):
    data=PartyModel.objects.get(id=id)
    Clr=ClusterModel.objects.all()
    if request.method=="POST":    
        data.Code=request.POST.get('Code')
        data.PartyName=request.POST.get('PartyName')
        data.Cluster=request.POST.get('Cluster')
        data.City=request.POST.get('City')
        data.Branch=request.POST.get('Branch')
        data.Address=request.POST.get('Address')
        data.GSTNo=request.POST.get('GSTNo')
        data.NO1=request.POST.get('NO1')
        data.NO2=request.POST.get('NO2')
        data.NO3=request.POST.get('NO3')
        data.NO4=request.POST.get('NO4')
        data.NO5=request.POST.get('NO5')
        data.NO6=request.POST.get('NO6')
        data.save()
        return redirect('/Party')
    return render(request,'editparty.html',{'data':data,'Clr':Clr})

@login_required(login_url='Login')
def DeleteParty(request,id):
    data=PartyModel.objects.get(id=id)
    data.delete()
    return redirect('/Party')

@login_required(login_url='Login')
def Labour(request):
    data=LabourModel.objects.all()
    return render(request,'labour.html',{'data':data})

@login_required(login_url='Login')
def AddLabour(request):
    if request.method=="POST":    
        Name=request.POST.get('Name')
        Address=request.POST.get('Address')
        Mobile1=request.POST.get('MobileNo1')
        Mobile2=request.POST.get('MobileNo1')
        Remarks=request.POST.get('Remarks')
        dt=LabourModel.objects.create(Name=Name,Address=Address,Mobile1=Mobile1,Mobile2=Mobile2,Remarks=Remarks)
        dt.save()
        return redirect('/Labour')
    return render(request,'addlabour.html')

@login_required(login_url='Login')
def EditLabour(request,id):
    data=LabourModel.objects.get(id=id)
    if request.method=="POST":    
        data.Name=request.POST.get('Name')
        data.Address=request.POST.get('Address')
        data.Mobile1=request.POST.get('MobileNo1')
        data.Mobile2=request.POST.get('MobileNo2')
        data.Remarks=request.POST.get('Remarks')
        data.save()
        return redirect('/Labour')
    return render(request,'editlabour.html',{'data':data})

@login_required(login_url='Login')
def DeleteLabour(request,id):
    data=LabourModel.objects.get(id=id)
    data.delete()
    return redirect('/Labour')

@login_required(login_url='Login')
def Rate(request):
    data=RateModel.objects.all()
    return render(request,'rate.html',{'data':data})

@login_required(login_url='Login')
def AddRate(request):
    data=GSTModel.objects.all()
    if request.method=="POST":    
        CodeNo=request.POST.get('CodeNo')
        Description=request.POST.get('Description')
        HSNCode=request.POST.get('HSNCode')
        Unit=request.POST.get('Unit')
        Rate=request.POST.get('Rate')
        Remarks=request.POST.get('Remarks')
        GSTName=request.POST.get('GSTName')
        data=GSTModel.objects.get(GSTName=GSTName)
        SGST=data.SGST
        CGST=data.CGST    
        IGSTName=request.POST.get('IGSTName')
        IGST=0
        dt=RateModel.objects.create(CodeNo=CodeNo,Description=Description,HSNCode=HSNCode,Unit=Unit,Rate=Rate,Remarks=Remarks,GSTName=GSTName,SGST=SGST,CGST=CGST,IGSTName=IGSTName,IGST=IGST)
        dt.save()
        return redirect('/Rate')
    return render(request,'addrate.html',{'data':data})

@login_required(login_url='Login')
def EditRate(request,id):
    gst=GSTModel.objects.all()
    data=RateModel.objects.get(id=id)
    if request.method=="POST":    
        data.CodeNo=request.POST.get('CodeNo')
        data.Description=request.POST.get('Description')
        data.HSNCode=request.POST.get('HSNCode')
        data.Unit=request.POST.get('Unit')
        data.Rate=request.POST.get('Rate')
        data.Remarks=request.POST.get('Remarks')
        GSTName=request.POST.get('GSTName')
        data.GSTName=GSTName
        dt=GSTModel.objects.get(GSTName=GSTName)
        data.SGST=dt.SGST
        data.CGST=dt.CGST    
        data.IGSTName=request.POST.get('IGSTName')
        data.IGST=0
        data.save()
        return redirect('/Rate')
    return render(request,'editrate.html',{'data':data,'gst':gst})

@login_required(login_url='Login')
def DeleteRate(request,id):
    data=RateModel.objects.get(id=id)
    data.delete()
    return redirect('/Rate')

@login_required(login_url='Login')
def Invoice(request):
    dt=InvoiceModel.objects.all()
    data={'dt':dt}
    return render(request,'invoice.html',data)

@login_required(login_url='Login')
def AddInvoice(request):
    try:
        CM=ICountModel.objects.get(id=1)
        InvoiceNo = CM.InvoiceNo
    except ICountModel.DoesNotExist:
        CM=ICountModel.objects.create(InvoiceNo=1)
        InvoiceNo = 1
    PN=PartyModel.objects.all()
    PN={i.PartyName for i in PN} 
    maindata={"PN":PN,'InvoiceNo':InvoiceNo}
    if request.method=="POST":    
        PartyName=request.POST.get('PartyName')
        datein=request.POST.get('datein')
        Type=request.POST.get('Type')
        if datein == 'Date':
            FromDate=request.POST.get('FromDate')
            ToDate=request.POST.get('ToDate')
            show=EntryModel.objects.filter(PartyName=PartyName,CallType=Type,Date__range=[FromDate, ToDate],complet='0')
            ttl = 0
            for i in show:
                ttl += eval(i.TotalAmount)
            ttl = "%.2f" % ttl
            maindata={"PN":PN,'InvoiceNo':InvoiceNo,'show':show,'PartyName':PartyName,'Type':Type,'datein':datein,'FromDate':FromDate,'ToDate':ToDate,'ttl':ttl}
        else:
            show=EntryModel.objects.filter(PartyName=PartyName,CallType=Type,complet='0')
            ttl = 0
            for i in show:
                ttl += eval(i.TotalAmount)
            ttl = "%.2f" % ttl
            maindata={"PN":PN,'InvoiceNo':InvoiceNo,'show':show,'PartyName':PartyName,'Type':Type,'datein':datein,'ttl':ttl}
    return render(request,'addinvoice.html',maindata)

def PartyName(request,PN):
    show=EntryModel.objects.filter(PartyName=PN).values()
    show=list(show)
    return JsonResponse({'show':show})

@login_required(login_url='Login')
def AddInvoiceMaIN(request):
    if request.method=="POST":
        InvoiceData=request.POST.get('InvoiceData')
        InvoiceNo=request.POST.get('InvoiceNo')
        BillMonth=request.POST.get('BillMonth')
        BillYear=request.POST.get('BillYear')
        Tax=request.POST.get('Tax')
        TotalA=request.POST.get('TotalAmount')
        PartyName=request.POST.get('PartyName')
        datein=request.POST.get('datein')
        Type=request.POST.get('Type')
        if TotalA:
            TA = eval(TotalA)
        else:
            TA = 0
        if 0 < TA:
            if datein == 'Date':
                FromDate=request.POST.get('FromDate')
                ToDate=request.POST.get('ToDate')
                show=EntryModel.objects.filter(PartyName=PartyName,CallType=Type,Date__range=[FromDate, ToDate],complet='0')
                for i in show:
                    dt = RCModel.objects.filter(Counter=i.Counter)
                    GA=0
                    for j in dt:
                        Rate = RateModel.objects.get(CodeNo=j.RCCode)
                        GSTRate = Rate.SGST
                        GSTAmount = eval(j.Amount)* eval(GSTRate) / 100
                        GSTTA = GSTAmount + GSTAmount
                        GA +=GSTTA
                        TotalAmount = eval(j.Amount) + GSTTA
                        GSTTA = "%.2f" % GSTTA
                        GSTAmount = "%.2f" % GSTAmount
                        TotalAmount = "%.2f" % TotalAmount
                        IRCM = InvoiceRCModel.objects.create(InvoiceNo=InvoiceNo,Counter=j.Counter,RCCode=j.RCCode,RCDescription=j.RCDescription,Quantity=j.Quantity,Rate=j.Rate,Labour=j.Labour,Amount=j.Amount,GSTRate=GSTRate,GSTAmount=GSTAmount,GSTTA=GSTTA,TotalAmount=TotalAmount)
                        IRCM.save()
                    GA = GA
                    TotalAmount = GA + eval(TotalA)
                    TotalAmount = "%.2f" % TotalAmount
                    i.complet = '1'
                    i.save()
                MainInvoice = InvoiceModel.objects.create(PartyName=PartyName,InvoiceData=InvoiceData,InvoiceNo=InvoiceNo,BillMonth=BillMonth,BillYear=BillYear,Tax=Tax,datein=datein,Type=Type,FromDate=FromDate,ToDate=ToDate,Amount=TotalA,GSTAmount=GA,TotalAmount=TotalAmount)
                MainInvoice.save()
                CM = ICountModel.objects.get(id=1)
                CM.InvoiceNo = int(InvoiceNo)+1
                CM.save()
                return redirect("/AddInvoice")
            else:
                show=EntryModel.objects.filter(PartyName=PartyName,CallType=Type,complet='0')
                for i in show:
                    dt = RCModel.objects.filter(Counter=i.Counter)
                    GA=0
                    for j in dt:
                        Rate = RateModel.objects.get(CodeNo=j.RCCode)
                        GSTRate = Rate.SGST
                        GSTAmount = eval(j.Amount) * int(GSTRate) / 100
                        GSTTA = GSTAmount + GSTAmount
                        GA +=GSTTA
                        TotalAmount = eval(j.Amount) + GSTTA
                        GSTTA = "%.2f" % GSTTA
                        GSTAmount = "%.2f" % GSTAmount
                        TotalAmount = "%.2f" % TotalAmount
                        IRCM = InvoiceRCModel.objects.create(InvoiceNo=InvoiceNo,Counter=j.Counter,RCCode=j.RCCode,Unit=j.Unit,HSNCode=j.HSNCode,RCDescription=j.RCDescription,Quantity=j.Quantity,Rate=j.Rate,Labour=j.Labour,Amount=j.Amount,GSTRate=GSTRate,GSTAmount=GSTAmount,GSTTA=GSTTA,TotalAmount=TotalAmount)
                        IRCM.save()
                    GA = GA
                    TotalAmount = GA + eval(TotalA)
                    TotalAmount = "%.2f" % TotalAmount
                    i.complet = '1'
                    i.save()
                MainInvoice = InvoiceModel.objects.create(PartyName=PartyName,InvoiceData=InvoiceData,InvoiceNo=InvoiceNo,BillMonth=BillMonth,BillYear=BillYear,Tax=Tax,datein=datein,Type=Type,Amount=TotalA,GSTAmount=GA,TotalAmount=TotalAmount)
                MainInvoice.save()
                CM = ICountModel.objects.get(id=1)
                CM.InvoiceNo = int(InvoiceNo)+1
                CM.save()
                return redirect("/AddInvoice")
        else:
            return redirect("/AddInvoice")
        
@login_required(login_url='Login')
def QuotationEntry(request):
    # data=EntryModel.objects.filter(complet='0')
    # return render(request,'callentry.html',{'data':data})
    return render(request,'quotation.html')

@login_required(login_url='Login')
def AddQuotation(request):
    try:
        CM=QCountModel.objects.get(id=1)
        QuotationNo = CM.QuotationNo
    except QCountModel.DoesNotExist:
        CM=QCountModel.objects.create(QuotationNo=1)
        QuotationNo = 1
    PN=PartyModel.objects.all()
    PN={i.PartyName for i in PN} 
    CC=CostCodeModel.objects.all()
    Cluster=ClusterModel.objects.all()
    RC = RateModel.objects.all()
    RCM=QTTModel.objects.all()
    RCM2=QTTModel.objects.filter(Counter=QuotationNo)
    TAmount=0
    for i in RCM2:
        TAmount=TAmount+ eval(i.Amount)
    maindata={'Party':Party,'CC':CC,'CM':CM,'RC':RC,'RCM':RCM,'RCM2':RCM2,'QuotationNo':QuotationNo,'PN':PN,'Cluster':Cluster}
    return render(request,'addquotation.html',maindata)

def QRCCreat(request):
    if request.method == 'POST':
        sid = request.POST.get('sid')
        Counter = request.POST['Counter']
        RCCode = request.POST['RCCode']
        RCDescription = request.POST['RCDescription']
        Quantity = request.POST['Quantity']
        Rate = request.POST['Rate']
        Labour = request.POST['Labour']
        Amount = request.POST['Amount']
        if sid == '':
            data=QTTModel(Counter=Counter,RCCode=RCCode,RCDescription=RCDescription,Quantity=Quantity,Rate=Rate,Labour=Labour,Amount=Amount)
        else:
            data=QTTModel(id=sid,Counter=Counter,RCCode=RCCode,RCDescription=RCDescription,Quantity=Quantity,Rate=Rate,Labour=Labour,Amount=Amount)
        data.save()
        # data load
        show=QTTModel.objects.filter(Counter=Counter).values()
        RCM2=QTTModel.objects.filter(Counter=Counter)
        TAmount=0
        for i in RCM2:
            TAmount=TAmount+ eval(i.Amount)
        show=list(show)
        return JsonResponse({'show':show,'TAmount':TAmount})
    
def QRCEdit(request):
    if request.method == 'POST':
        id = request.POST.get('sid')
        data=QTTModel.objects.get(pk=id)
        mydata={"id":data.id,"Counter":data.Counter,"RCCode":data.RCCode,"RCDescription":data.RCDescription,"Quantity":data.Quantity,"Rate":data.Rate,"Labour":data.Labour,"Amount":data.Amount}
        return JsonResponse(mydata)

def QRCDelete(request):
    if request.method == 'POST':
        id = request.POST.get('sid')
        data=QTTModel.objects.get(pk=id)
        i=data.Counter
        data.delete()
        RCM2=QTTModel.objects.filter(Counter=i)
        TAmount=0
        for i in RCM2:
            TAmount=TAmount+ eval(i.Amount)
        return JsonResponse({'status':1,'TAmount':TAmount})
    else:
        return JsonResponse({'status':0})
    
@login_required(login_url='Login')
def ClaseQuotation(request,id):
        data=QTTModel.objects.filter(Counter=id)
        data.delete()
        return redirect('/Quotation')

@login_required(login_url='Login')
def TaxInvoice(request,id):
    dt=InvoiceModel.objects.get(id=id)
    party = PartyModel.objects.all()
    Rc = InvoiceRCModel.objects.filter(InvoiceNo=dt.InvoiceNo)
    Amount = 0
    GSTAmount = 0
    TotalAmount = 0
    for j in Rc:
        Amount += eval(j.Amount)
        GSTAmount += eval(j.GSTAmount)
        TotalAmount += eval(j.TotalAmount)
    Amount = "%.2f" % Amount
    GSTAmount = "%.2f" % GSTAmount
    TotalAmount = "%.2f" % TotalAmount
    p = {}
    for i in party:
        p['PartyName'] = i.PartyName
        break
    main={'dt':dt,'party':party,'p':p,'Rc':Rc,'Amount':Amount,'GSTAmount':GSTAmount,'TotalAmount':TotalAmount}
    return render(request,'taxinvoice.html',main)